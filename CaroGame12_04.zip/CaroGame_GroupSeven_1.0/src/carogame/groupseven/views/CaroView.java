package carogame.groupseven.views;


import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.*;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.eclipse.wb.swt.SWTResourceManager;

import carogame.groupseven.model.CheckWiner;
import carogame.groupseven.model.Player;

import org.eclipse.jface.viewers.*;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.jface.action.*;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.*;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ViewForm;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.ResourceManager;




/**
 * This sample class demonstrates how to plug-in a new
 * workbench view. The view shows data obtained from the
 * model. The sample creates a dummy model on the fly,
 * but a real implementation would connect to the model
 * available either in this or another plug-in (e.g. the workspace).
 * The view is connected to the model using a content provider.
 * <p>
 * The view uses a label provider to define how model
 * objects should be presented in the view. Each
 * view can present the same model objects using
 * different labels and icons, if needed. Alternatively,
 * a single label provider can be shared between views
 * in order to ensure that objects of the same type are
 * presented in the same way everywhere.
 * <p>
 */

public class CaroView extends ViewPart {

	/**
	 * The ID of the view as specified by the extension.
	 */
	public static final String ID = "carogame.groupseven.views.CaroView";
	private Text txtSize;
	//private Text txtWight;
	public String txtPlayer1name;
	public String txtPlayer2name;
	public static Composite Boardparent;
	public static Board mainBoard;
	public static Label lblPlayer1;
	
	
	private static ImageDescriptor imaPlayerO = AbstractUIPlugin.imageDescriptorFromPlugin("CaroGame_GroupSeven", "icons/playerO.png");
	
	Image imagePlayerO = imaPlayerO.createImage();
	/*
	 * The content provider class is responsible for
	 * providing objects to the view. It can wrap
	 * existing objects in adapters or simply return
	 * objects as-is. These objects may be sensitive
	 * to the current input of the view, or ignore
	 * it and always show the same content 
	 * (like Task List, for example).
	 */

	/**
	 * The constructor.
	 */
	public CaroView() {
		mainBoard = new Board();
	}
	
	/*public void Congratulation ()
	{
		Label congra= new Label(grpPlayer1,SWT.NONE);
		congra.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		congra.setAlignment(SWT.CENTER);
		congra.setFont(SWTResourceManager.getFont("Times New Roman", 20, SWT.BOLD));
		congra.setBounds(50, 50, 400, 50);
		congra.setText("Congratulation!You win!");
	}*/
	/**
	 * This is a callback that will allow us
	 * to create the viewer and initialize it.
	 */
	public void createPartControl(Composite parent) {
		Boardparent = parent;
		parent.setLayout(null);
		
		Group grpPlayer1 = new Group(parent, SWT.NONE);
		grpPlayer1.setBounds(810, 0, 450, 315);
		grpPlayer1.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/2.jpg")));
		//grpPlayer1.setBackgroundImage(ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/playerO.png"));
		
		
		/*Group grpScore_player1 = new Group(grpPlayer1, SWT.NONE);
		grpScore_player1.setBackground(SWTResourceManager.getColor(240, 240, 240));
		grpScore_player1.setBounds(10, 331, 180, 72);
		
		Label lblPlayer1_score = new Label(grpScore_player1, SWT.NONE);
		lblPlayer1_score.setForeground(SWTResourceManager.getColor(SWT.COLOR_DARK_MAGENTA));
		lblPlayer1_score.setAlignment(SWT.CENTER);
		lblPlayer1_score.setFont(SWTResourceManager.getFont("Tempus Sans ITC", 13, SWT.BOLD));
		lblPlayer1_score.setBounds(53, 10, 69, 26);
		lblPlayer1_score.setText("SCORE");
		
		Label lblScore1 = new Label(grpScore_player1, SWT.NONE);
		lblScore1.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLUE));
		lblScore1.setAlignment(SWT.CENTER);
		lblScore1.setFont(SWTResourceManager.getFont("Tempus Sans ITC", 20, SWT.BOLD));
		lblScore1.setBounds(29, 30, 116, 39);
		lblScore1.setText("0");*/
		
		Label lblPlayer1 = new Label(grpPlayer1, SWT.NONE);
		lblPlayer1.setForeground(SWTResourceManager.getColor(SWT.COLOR_DARK_CYAN));
		lblPlayer1.setAlignment(SWT.CENTER);
		lblPlayer1.setFont(SWTResourceManager.getFont("Times New Roman", 25, SWT.BOLD));
		lblPlayer1.setBounds(10, 10, 180, 48);
		lblPlayer1.setText("Player 1");
		
		
		//Label lblPlayerO = new Label(grpPlayer1, SWT.CENTER);
		//lblPlayerO.setImage(ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/playerO.png"));
		//lblPlayerO.setBounds(42, 57, 135, 227);
		
	/*	Label lblPlayer1Name = new Label(grpPlayer1, SWT.NONE);
		lblPlayer1Name.setBounds(10, 409, 176, 29);
		lblPlayer1Name.setText("Player 1 's name:");
		lblPlayer1Name.setFont(SWTResourceManager.getFont("Tempus Sans ITC", 12, SWT.BOLD));
		lblPlayer1Name.setAlignment(SWT.CENTER);
		
		Label lblName1 = new Label(grpPlayer1, SWT.NONE);
		lblName1.setAlignment(SWT.CENTER);
		lblName1.setFont(SWTResourceManager.getFont("Tempus Sans ITC", 12, SWT.NORMAL));
		lblName1.setBounds(10, 303, 180, 29);
		
		txtPlayer1name = new Text(grpPlayer1, SWT.BORDER | SWT.CENTER);
		txtPlayer1name.setBounds(10, 444, 180, 30);
		txtPlayer1name.setFont(SWTResourceManager.getFont("Viner Hand ITC", 12, SWT.NORMAL));
		*/
		Group grpPlayer2 = new Group(parent, SWT.NONE);
		grpPlayer2.setBounds(810, 315, 450, 315);
		grpPlayer2.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/zed.jpg")));
		
		Label lblPlayer2 = new Label(grpPlayer2, SWT.CENTER);
		lblPlayer2.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblPlayer2.setFont(SWTResourceManager.getFont("Times New Roman", 25, SWT.BOLD));
		lblPlayer2.setBounds(10, 10, 180, 48);
		lblPlayer2.setText("Player 2");
		
		/*Group grpScore_player2 = new Group(grpPlayer2, SWT.NONE);
		grpScore_player2.setBackground(SWTResourceManager.getColor(240, 240, 240));
		grpScore_player2.setBounds(10, 331, 180, 72);
		
		Label lblPlayer2_score = new Label(grpScore_player2, SWT.NONE);
		lblPlayer2_score.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblPlayer2_score.setText("SCORE");
		lblPlayer2_score.setFont(SWTResourceManager.getFont("Tempus Sans ITC", 13, SWT.BOLD));
		lblPlayer2_score.setAlignment(SWT.CENTER);
		lblPlayer2_score.setBounds(58, 10, 69, 26);
		
		Label lblScore2 = new Label(grpScore_player2, SWT.NONE);
		lblScore2.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblScore2.setText("0");
		lblScore2.setFont(SWTResourceManager.getFont("Tempus Sans ITC", 20, SWT.BOLD));
		lblScore2.setAlignment(SWT.CENTER);
		lblScore2.setBounds(34, 30, 116, 39);
		
		Label lblPlayer2name = new Label(grpPlayer2, SWT.NONE);
		lblPlayer2name.setBounds(14, 409, 176, 29);
		lblPlayer2name.setText("Player 2 's name:");
		lblPlayer2name.setFont(SWTResourceManager.getFont("Tempus Sans ITC", 12, SWT.BOLD));
		lblPlayer2name.setAlignment(SWT.CENTER);
		
		txtPlayer2name = new Text(grpPlayer2, SWT.BORDER | SWT.CENTER);
		txtPlayer2name.setBounds(12, 444, 180, 30);
		txtPlayer2name.setFont(SWTResourceManager.getFont("Viner Hand ITC", 13, SWT.NORMAL));
		
		Label lblName2 = new Label(grpPlayer2, SWT.NONE);
		lblName2.setFont(SWTResourceManager.getFont("Tempus Sans ITC", 12, SWT.NORMAL));
		lblName2.setAlignment(SWT.CENTER);
		lblName2.setBounds(10, 303, 180, 29);*/
		
		/*Label lblPlayerX = new Label(grpPlayer2, SWT.SHADOW_NONE | SWT.CENTER);
		lblPlayerX.setImage(ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/playerO.png"));
		lblPlayerX.setBounds(34, 57, 132, 227);
		//lblPlayerX.setImage(ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/playerX.gif"));
/*player1 score */			
		Group group = new Group(parent, SWT.NONE);	
		group.setBounds(600, 0, 200, 315);
		group.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/1.jpg")));
		
		Label lblPlayer1Name = new Label(group, SWT.NONE);
		lblPlayer1Name.setBounds(10, 10, 180, 30);
		lblPlayer1Name.setForeground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblPlayer1Name.setText("Player 1 's name:");
		lblPlayer1Name.setFont(SWTResourceManager.getFont("Times New Roman", 18, SWT.BOLD));
		lblPlayer1Name.setAlignment(SWT.CENTER);
		
		Label player1_name = new Label(group, SWT.NONE);
		player1_name.setBounds(10, 45, 180, 30);
		player1_name.setFont(SWTResourceManager.getFont("Times New Roman", 12, SWT.NORMAL));
		txtPlayer1name=player1_name.getText();
		/*Label lblName1 = new Label(grpPlayer1, SWT.NONE);
		lblName1.setAlignment(SWT.CENTER);
		lblName1.setFont(SWTResourceManager.getFont("Tempus Sans ITC", 12, SWT.NORMAL));
		lblName1.setBounds(10, 303, 180, 29);*/
		
		Group grpScore_player1 = new Group(group, SWT.NONE);
		grpScore_player1.setBackground(SWTResourceManager.getColor(240, 240, 240));
		grpScore_player1.setBounds(10, 100, 180, 72);
		
		Label lblPlayer1_score = new Label(grpScore_player1, SWT.NONE);
		lblPlayer1_score.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblPlayer1_score.setAlignment(SWT.CENTER);
		lblPlayer1_score.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.BOLD));
		lblPlayer1_score.setBounds(53, 10, 69, 26);
		lblPlayer1_score.setText("SCORE");
		
		Label lblScore1 = new Label(grpScore_player1, SWT.NONE);
		lblScore1.setForeground(SWTResourceManager.getColor(SWT.COLOR_DARK_CYAN));
		lblScore1.setAlignment(SWT.CENTER);
		lblScore1.setFont(SWTResourceManager.getFont("Times New Roman", 20, SWT.BOLD));
		lblScore1.setBounds(29, 30, 116, 39);
		lblScore1.setText(Player.timeP1win + "");
		
		/*Label lblSize = new Label(group, SWT.NONE);
		lblSize.setBounds(20, 200,170, 21);
		lblSize.setAlignment(SWT.LEFT);
		lblSize.setFont(SWTResourceManager.getFont("Tempus Sans ITC", 13, SWT.BOLD));
		lblSize.setText("Size from 15 to 30");
		
		txtSize = new Text(group, SWT.BORDER | SWT.CENTER);
		txtSize.setBounds(33, 250, 130, 30);
		txtSize.setFont(SWTResourceManager.getFont("Viner Hand ITC", 13, SWT.NORMAL));
		
		Label lblWight = new Label(group, SWT.NONE);
		lblWight.setBounds(60, 300, 76, 25);
		lblWight.setAlignment(SWT.CENTER);
		lblWight.setFont(SWTResourceManager.getFont("Tempus Sans ITC", 13, SWT.BOLD));
		lblWight.setText("Wight");
		
		txtHeight = new Text(group, SWT.BORDER | SWT.CENTER);
		txtHeight.setBounds(33, 350, 130, 30);
		txtHeight.setFont(SWTResourceManager.getFont("Viner Hand ITC", 13, SWT.NORMAL));*/
/*player2 score */	
		Group group_2 = new Group(parent, SWT.NONE);	
		group_2.setBounds(600, 315, 200, 315);
		group_2.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/6.jpg")));
		
		Label lblPlayer2Name = new Label(group_2, SWT.NONE);
		lblPlayer2Name.setBounds(10, 10, 180, 30);
		lblPlayer2Name.setText("Player 2 's name:");
		lblPlayer2Name.setFont(SWTResourceManager.getFont("Times New Roman", 12, SWT.BOLD));
		lblPlayer2Name.setAlignment(SWT.CENTER);
		
		Label player2_name = new Label(group, SWT.NONE);
		player2_name.setBounds(10, 45, 180, 30);
		player2_name.setFont(SWTResourceManager.getFont("Times New Roman", 12, SWT.NORMAL));
		txtPlayer2name=player2_name.getText();
		/*Label lblName1 = new Label(grpPlayer1, SWT.NONE);
		lblName1.setAlignment(SWT.CENTER);
		lblName1.setFont(SWTResourceManager.getFont("Tempus Sans ITC", 12, SWT.NORMAL));
		lblName1.setBounds(10, 303, 180, 29);*/
		
		Group grpScore_player2 = new Group(group_2, SWT.NONE);
		grpScore_player2.setBackground(SWTResourceManager.getColor(240, 240, 240));
		grpScore_player2.setBounds(10, 100, 180, 72);
		
		Label lblPlayer2_score = new Label(grpScore_player2, SWT.NONE);
		lblPlayer2_score.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblPlayer2_score.setAlignment(SWT.CENTER);
		lblPlayer2_score.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.BOLD));
		lblPlayer2_score.setBounds(53, 10, 69, 26);
		lblPlayer2_score.setText("SCORE");
		
		Label lblScore2 = new Label(grpScore_player2, SWT.NONE);
		lblScore2.setForeground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblScore2.setAlignment(SWT.CENTER);
		lblScore2.setFont(SWTResourceManager.getFont("Times New Roman", 20, SWT.BOLD));
		lblScore2.setBounds(29, 30, 116, 39);
		lblScore2.setText(Player.timeP2win + "");
		
		Group group_1 = new Group(parent, SWT.NONE);
		group_1.setBounds(0, 510, 600, 120);
		
		Button btnNewGame = new Button(group_1, SWT.NONE);
		btnNewGame.setBounds(20, 20, 150, 40);
		btnNewGame.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.BOLD));
		btnNewGame.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(mainBoard.initBoard(getWidth(), getHeight()))
				{
					mainBoard.Calcu_CELL(getWidth(), getHeight());
					mainBoard.drawBoard();
					//createPartControl(parent);
					lblScore1.setText(Player.timeP1win + "");
					lblScore2.setText(Player.timeP2win + "");
				}
			}
		});
		btnNewGame.setText("NEW GAME");
		
		Button btnReSet = new Button(group_1, SWT.NONE);
		btnReSet.setBounds(200, 20, 150, 40);
		btnReSet.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_DARK_SHADOW));
		btnReSet.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.BOLD));
		btnReSet.setText("RESET SCORE");
		
		btnReSet.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(mainBoard.initBoard(getWidth(), getHeight()))
				{
					Player.timeP1win=0;
					Player.timeP2win=0;
					lblScore1.setText(Player.timeP1win + "");
					lblScore2.setText(Player.timeP2win + "");
				}
			}
		});
		
		Label lblSize = new Label(group_1, SWT.NONE);
		lblSize.setBounds(400, 20,170, 21);
		lblSize.setAlignment(SWT.LEFT);
		lblSize.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.BOLD));
		lblSize.setText("Size from 15 to 30");
		
		txtSize = new Text(group_1, SWT.BORDER | SWT.CENTER);
		txtSize.setBounds(400, 70, 130, 30);
		txtSize.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.NORMAL));
		
		/*if (CheckWiner.won==true)
		{
			Group group_congra= new Group(parent,SWT.NONE);
			group_congra.setBounds(250, 250, 400, 200);
			
			Label congra= new Label(group_congra,SWT.NONE);
			congra.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
			congra.setAlignment(SWT.CENTER);
			congra.setFont(SWTResourceManager.getFont("Tempus Sans ITC", 20, SWT.BOLD));
			congra.setBounds(0, 30, 200, 50);
			congra.setText("Congratulation!You win!");
		}*/
	}

	private int getWidth()
	{
		int width = Integer.parseInt(txtSize.getText());
		return width;
	}
	
	
	private int getHeight()
	{
		int height = Integer.parseInt(txtSize.getText());
		return height;
	}
	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
		
	}
}
