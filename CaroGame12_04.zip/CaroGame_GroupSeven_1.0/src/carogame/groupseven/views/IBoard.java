package carogame.groupseven.views;

public interface IBoard {

	boolean hasWiner();
	void initBoardGame(int size);
	int getTurn();
}
