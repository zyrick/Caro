package carogame.groupseven.model;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;

import javax.swing.JOptionPane;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.eclipse.wb.swt.SWTResourceManager;

import carogame.groupseven.views.Board;
import carogame.groupseven.views.CaroView;


public class Cell extends Canvas{

	private CheckWiner iWiner = new CheckWiner();
	private static ImageDescriptor imgCross = AbstractUIPlugin.imageDescriptorFromPlugin("CaroGame_GroupSeven", "icons/4.png");
	private static ImageDescriptor imgNought = AbstractUIPlugin.imageDescriptorFromPlugin("CaroGame_GroupSeven", "icons/5.jpg");
	private static ImageDescriptor imgCrossA = AbstractUIPlugin.imageDescriptorFromPlugin("CaroGame_GroupSeven", "icons/4.png");
	private static ImageDescriptor imgNoughtA = AbstractUIPlugin.imageDescriptorFromPlugin("CaroGame_GroupSeven", "icons/5.jpg");
		
	static Image imageCross = imgCross.createImage();
	static Image imageNought = imgNought.createImage();
	static Image imageCrossA = imgCrossA.createImage();
	static Image imageNoughtA = imgNoughtA.createImage();
	static ImageData imageNoughtA_data = imgNoughtA.getImageData();
	static ImageData imageNought_data = imgNought.getImageData();
	static ImageData imageCross_data = imgCross.getImageData();
	static ImageData imageCrossA_data = imgCrossA.getImageData();
	 
	public byte C_Player = 0;
	public boolean Current_Player = false;
	public boolean W_CellFlag = false;
	public static int X_Before = 0;
	public static int Y_Before = 0;
	public static int OLDX_Before = 0;
	public static int OLDY_Before = 0;
	private CaroView caroview;
	//private int announce;
	public Cell(Composite parent, int style) {
		super (parent, style);
		// TODO Auto-generated constructor stub	
		addListener(SWT.Paint, new Listener() {
			
			@Override
			public void handleEvent(Event event) {
				// TODO Auto-generated method stub
				
				if(C_Player == Player.PLAYER_1)
				{
					if (Current_Player || W_CellFlag) {
						
						ImageData imageNoughtA_dt =  imageNoughtA_data.scaledTo((carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3),(carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3));
						Image tempNoughtA = new Image(imageNoughtA.getDevice() ,imageNoughtA_dt);
						event.gc.drawImage(tempNoughtA, 0, 0);
						Current_Player = false;
					}
					else
					{
						ImageData imageNought_dt =  imageNought_data.scaledTo((carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3),(carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3));
						Image tempNought = new Image(imageNought.getDevice() ,imageNought_dt);
						event.gc.drawImage(tempNought, 0, 0);
					}
				}
				else if(C_Player == Player.PLAYER_2)
				{
					if (Current_Player || W_CellFlag) {
						
						ImageData imageCrossA_dt =  imageCrossA_data.scaledTo((carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3),(carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3));
						Image tempCrossA = new Image(imageCrossA.getDevice() ,imageCrossA_dt);
						event.gc.drawImage(tempCrossA, 0, 0);
						Current_Player = false;
					}
					else
					{
						ImageData imageCross_dt =  imageCross_data.scaledTo((carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3),(carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3));
						Image tempCross = new Image(imageCross.getDevice() ,imageCross_dt);
						event.gc.drawImage(tempCross, 0, 0);
					}
				}
				else
				{
					event.gc.setBackground(Display.getDefault().getSystemColor(SWT.COLOR_WHITE));
					event.gc.fillRectangle(0, 0, carogame.groupseven.views.CaroView.mainBoard.getCell_W_H() , carogame.groupseven.views.CaroView.mainBoard.getCell_W_H());
				}
				
			}
		});
		
		addListener(SWT.MouseDown, new Listener() {
			
			private Board mainBoard;
			//private String txtPlayer1name;

			@Override
			public void handleEvent(Event event) {
				// TODO Auto-generated method stub
				
				if(!CheckWiner.won){
					if((C_Player != Player.PLAYER_1)&&(C_Player != Player.PLAYER_2)){
						//Check to lose player plays first.
						if(Player.Winer == Player.PLAYER_1){
							Player.clickPlayer = Player.PLAYER_2;
							C_Player = Player.PLAYER_2;
							Player.Winer = 0;
						}
						else if(Player.Winer == Player.PLAYER_2){
							Player.clickPlayer = Player.PLAYER_1;
							C_Player = Player.PLAYER_1;
							Player.Winer = 0;
						}
						else{
							if((Player.clickPlayer == Player.PLAYER_1)){
								Player.clickPlayer = Player.PLAYER_2;
								C_Player = Player.PLAYER_2;
							}
							else{
								Player.clickPlayer = Player.PLAYER_1;
								C_Player = Player.PLAYER_1;
							}
						}
						
						Current_Player = true;
						
						redraw();
						
						//Check winer
						if(iWiner.checkWinwer()){
							//NotifyMessage.notifyWiner();
						//	NotifyMessage.notifyScore();
						//	DrawTable.drawWinLine();
							
							//Group group_congra= new Group(parent,SWT.NONE);
							//group_congra.setBounds(50, 50, 400, 200);
							//Player.timeP2win++;
							//caroview.Congratulation();
							
							CaroView.lblPlayer1.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
							CaroView.lblPlayer1.setAlignment(SWT.CENTER);
							CaroView.lblPlayer1.setFont(SWTResourceManager.getFont("Times New Roman", 20, SWT.BOLD));
							CaroView.lblPlayer1.setBounds(10, 150, 400, 50);
							CaroView.lblPlayer1.setText("Congratulation!You win!");
							//announce=JOptionPane.OK_OPTION;
						}
						
						if(Board.checkBoard()){
						//	NotifyMessage.notifyDraw();
						}
						
					}
				}
				
			}
		});
		
		
		addListener(SWT.MouseUp, new Listener(){

			@Override
			public void handleEvent(Event event) {
				if(Player.firstStep != 0){
					Board.cell[OLDX_Before][OLDY_Before].redraw();
				}
				else{
					Player.firstStep = C_Player;
				}
				OLDX_Before = X_Before;
				OLDY_Before = Y_Before;
			}
			
		});
	}
	
	
}
