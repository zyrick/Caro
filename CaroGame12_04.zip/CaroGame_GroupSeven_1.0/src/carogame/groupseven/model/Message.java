package carogame.groupseven.model;

import carogame.groupseven.views.CaroView;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.SWTResourceManager;


public class Message {

	public static void Winer()
	{
		
	}
	
	
	
	
	
	
}
