package carogame.groupseven.model;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Group;

public class Player {
	
	public static byte PLAYER_1 = 1;
	public static byte PLAYER_2 = 2;
	
	public static byte timeP1win = 0;
	public static byte timeP2win = 0;
	
	public static byte firstStep = 0;
	public static byte clickPlayer = 0;
	public static byte Winer = 0;
}
