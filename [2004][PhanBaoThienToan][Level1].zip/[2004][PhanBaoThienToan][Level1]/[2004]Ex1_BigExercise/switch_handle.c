#include "switch_handle.h"
#include "lcd.h" 
#include "count_time.h"
extern char chuoi[9];
extern time_t p_time;
extern data_memory time[21];
extern char record[13];
extern count_u,count;
char stt = 'P';
int match_time=0,flag_update=0;
uint8_t sw_cur,sw_pre;
int pos=0,i=0,temp=0,up=0,down=0,index=0;
int flagu=0,flagd=0;
int checku=0,checkd=0,checkc=0;


/******************************************************************************
* Function Name: detectSW
* Description  : eliminate chattering and handle switch 1, switch 2,switch 3
* Arguments    : none
* Return Value : none
******************************************************************************/
void detectSW(void)
{
	if(match_time>=3)
	{
		match_time=0;
		sw_handle();
	}
	sw_cur= PORT7 &0x70;
	if(sw_cur!=sw_pre){
		match_time++;
	}
	else{
		match_time=0;
	}
}
/******************************************************************************
* Function Name: sw_handle
* Description  : handle switch 1, switch 2,switch 3
* Arguments    : none
* Return Value : none
******************************************************************************/
void sw_handle(void){
	switch (sw_cur)
	{
		case 0x50:
			if(stt=='P')
			{
				stt='C';
			}
			else if(stt=='C')
			{
				stt='R';
				pos=1;
				//save first data
				save(pos);
			}
			else if(stt=='R')
			{
				//checkc=1;
				pos++;
				save(pos);
			}
			flag_update=1;
			sw_pre=sw_cur;
			break;
		case 0x30:
			if((stt=='R')||(stt=='D'))
			{
				stt='U';
				up=1;
				//flagd=0;
			}
			else if(stt=='U')
			{
				if(flagu==1)
				{
				up=0;
				}
				
				up=1;
				
				stt=='U';
				checku=1;
			}
			break;
		case 0x60:
			if((stt=='R')||(stt=='U'))
			{
				stt='D';
				down=1;
				checkd=1;

			}
			else if(stt=='D')
			{
				if(flagd==0)
				{
				down++;
				}
				stt=='D';
				checkd=1;
				
			}
		default:
			flag_update=1;
			sw_pre=sw_cur;
		
	}
}
/******************************************************************************
* Function Name: update_LCD
* Description  : display time,status on LCD
* Arguments    : none
* Return Value : none
******************************************************************************/
void update_LCD(void)
{
	save_chuoi();
	
	switch(stt)
	{
		case 'P':
			DisplayLCD(LCD_LINE1,(uint8_t *)"PAUSED \0");
			DisplayLCD(LCD_LINE2,chuoi);
			break;
		case 'C':
			DisplayLCD(LCD_LINE1,(uint8_t *)"RUNNING...");
			DisplayLCD(LCD_LINE2,chuoi);
			DisplayLCD(LCD_LINE3,(uint8_t *)"NO RECORD");
			break;
		case 'R':
			DisplayLCD(LCD_LINE1,(uint8_t *)"RUNNING...");
			DisplayLCD(LCD_LINE2,chuoi);
			if(pos<=6)
			{	
				display_6();
			}
			else if((pos>6)&&(pos<21))
			{
				display_6_21();
			}
			else if (pos>20)
			{
				display_21_100();
			}
			break;
		case 'U':
			if(flagu==0)
			{
			DisplayLCD(LCD_LINE1,(uint8_t *)"RUNNING...");
			}
			DisplayLCD(LCD_LINE2,chuoi);
			display_crollup();
			break;
		case 'D':
			if(flagd==0)
			{
			DisplayLCD(LCD_LINE1,(uint8_t *)"RUNNING...");
			}
			DisplayLCD(LCD_LINE2,chuoi);
			display_crolldown();
			break;
	}

}

void check_strengthlen(void)
{
	if(time[temp].datanumber<=9)
		{
			record[1]=time[temp].datanumber+'0';
			record[2]=' ';
		}

		else if(time[temp].datanumber>9) {
			record[1]=time[temp].datanumber/10+'0';
			record[2]=time[temp].datanumber%10+'0';
		}
}

void save_string(void)
{
	record[3]=' ';
	record[4]=time[temp].number_minute/10+'0';
	record[5]=time[temp].number_minute%10+'0';
	record[6]=':';
	record[7]=time[temp].number_second/10+'0';
	record[8]=time[temp].number_second%10+'0';
	record[9]=':';
	record[10]=time[temp].number_centisecond/10+'0';
	record[11]=time[temp].number_centisecond%10+'0';
	record[12]='\0';
	DisplayLCD(8*(i+2),record);
	i++;
}

void save(int n)
{
	if(n>20)
	{
		for(i=1;i<20;i++)
		{
		time[i].number_centisecond=time[i+1].number_centisecond;
		time[i].number_second=time[i+1].number_second;
		time[i].number_minute=time[i+1].number_minute;
		time[i].datanumber=time[i+1].datanumber;
		}
		time[20].number_centisecond=p_time.centisecond;
		time[20].number_second=p_time.second;
		time[20].number_minute=p_time.minute;
		time[20].datanumber=n;
	}
	else {
	time[n].number_centisecond=p_time.centisecond;
	time[n].number_second=p_time.second;
	time[n].number_minute=p_time.minute;
	time[n].datanumber=n;
	}	
}

void display_6(void)
{
	record[0]='#';
	record[1]=time[pos].datanumber+'0';
	record[2]=' ';
	record[3]=' ';
	record[4]=time[pos].number_minute/10+'0';
	record[5]=time[pos].number_minute%10+'0';
	record[6]=':';
	record[7]=time[pos].number_second/10+'0';
	record[8]=time[pos].number_second%10+'0';
	record[9]=':';
	record[10]=time[pos].number_centisecond/10+'0';
	record[11]=time[pos].number_centisecond%10+'0';
	record[12]='\0';
	DisplayLCD(LCD_LINE2+pos*8,record);
}

void display_6_21(void)
{
	i=0;
	temp=pos-5;
	for(temp;temp<=pos;temp++)
	{
		check_strengthlen();			
		save_string();
		}
}

void display_21_100(void)
{
	i=0;
	temp=15;
	for(temp;temp<=20;temp++)
	{
		check_strengthlen();		
		save_string();
	}
}

void display_crollup(void)
{
	i=0;
	if(pos<=6)
	{
		index=1;
		first_record();
	}
	else if((pos<20)&&(pos>6)){

		temp=pos-5-up;
		index=temp;
		
		
		for(temp;temp<=index+5;temp++)
		{
			check_strengthlen();	
			save_string();	
		}

		first_record();
	}
	
	else if(pos>20)
	{
		i=0;
		if(down==0)
		{
			if(index==0){
				index=15;
			}
			temp=index-up;
			index=temp;
		}
		else{
			if(checku==1)
			{
			temp=index-up;//sai
			index=temp;
			}
		}

		for(temp;temp<=20-up;temp++)
		{
			check_strengthlen();			
			save_string();
		}
		first_record();
	}
		
}

void display_crolldown(void)
{
	i=0;
	if(pos>20)
	{
		if(up==0)
		{
			index=15;
			last_record();
		}
		else{
			if(checkd==1)
			{
			temp=index+down;
			index=temp;
			}

			for(temp;temp<=20+down;temp++)
			{
				check_strengthlen();
				save_string();
			}
			last_record();
		}
		
	}
}