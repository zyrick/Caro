#include "count_time.h"
#include "lcd.h" 
#include "timer.h"

extern char chuoi[9];
extern time_t p_time;
extern count_u,count;
extern char stt;
extern int up;
extern int flagu,flagd,index;
extern int checku,checkd;

void save_chuoi(void)
{
	chuoi[0]=p_time.minute/10 +'0';
	chuoi[1]=p_time.minute%10 +'0';
	chuoi[2]=':';
	chuoi[3]=p_time.second/10 +'0';
	chuoi[4]=p_time.second%10 +'0';
	chuoi[5]=':';
	chuoi[6]=p_time.centisecond/10+'0';
	chuoi[7]=p_time.centisecond%10+'0';
	chuoi[8]='\0';
}

void time_count(void)
{
	if(count>=TIMER_COUNT_INTERVAL)
	{
		count=0;
		p_time.centisecond+=10;
	}
	if(p_time.centisecond==100)
	{
		p_time.centisecond=0;
		p_time.second++;
	}
	if(p_time.second==60)
	{
		p_time.second=0;
		p_time.minute++;
	}
	if(p_time.minute==60)
	{
		p_time.centisecond=0;
		p_time.second=0;
		p_time.minute=0;
		stt='P';
	}
}

void first_record(void)
{
	up=0;
	count_u=0;
	if(index==1)
	{
		flagu=1;
	}
	else 
	{
		checku=0;
		up=0;
	}
	if((index==1)&&(checku==1))
	{
		while(count_u<=20)
		{
			time_count();
			save_chuoi();
			DisplayLCD(LCD_LINE2,chuoi);
			DisplayLCD(LCD_LINE1,(uint8_t *)"FIRST RECORD ");
		}
		DisplayLCD(LCD_LINE1,(uint8_t *)"             ");
		checku=0;
		up=0;
	}
	else if (flagu==1)
	{
		DisplayLCD(LCD_LINE1,(uint8_t *)"RUNNING...");
		checku=0;
		up=0;
	}	
}

void last_record(void)
{
	count_u=0;
	if(index==15)
	{
		flagd=1;
	}
	else checku=0;
	if((checkd==1)&&(index==15))
	{
		while(count_u<=20)
		{
			time_count();
			save_chuoi();
			DisplayLCD(LCD_LINE2,chuoi);
			DisplayLCD(LCD_LINE1,(uint8_t *)"LAST RECORD ");
		}
		DisplayLCD(LCD_LINE1,(uint8_t *)"             ");
		checkd=0;
	}
	else if(flagd==1)
	{
		DisplayLCD(LCD_LINE1,(uint8_t *)"RUNNING...");
		checkd=0;
	}	
}
	