#pragma sfr
#include "r_macro.h"  /* System macro and standard type definition */
#include "api.h"
#include "r_spi_if.h" /* SPI driver interface */
#include "adc.h"      /* ADC driver interface */
#include "timer.h"    /* Timer driver interface	*/
#include "led.h"      /* Led driver interface	*/




/******************************************************************************
* Function Name: led_select
* Description  : select which led to be turned on
* Arguments    :int led - the led to be turned on
* Return Value : none
******************************************************************************/
void led_select(int led)
{
	switch (led)
	{
	case 0:
		LED0=LED_ON;
		break;
	case 1:
		LED1=LED_ON;
		break;
	case 2:
		LED2=LED_ON;
		break;
	case 3:
		LED3=LED_ON;
		break;
	case 4:	
		LED4=LED_ON;
		break;
	case 5:
		LED5=LED_ON;
		break;
	case 6:
		LED6=LED_ON;
		break;
	case 7:
		LED7=LED_ON;
		break;
	case 8:
		LED8=LED_ON;
		break;
	case 9:
		LED9=LED_ON;
		break;
	case 10:
		LED10=LED_ON;
		break;
	case 11:
		LED11=LED_ON;
		break;
	}
}

/******************************************************************************
* Function Name: range_choose
* Description  : Choose the number of leds to be on acording to voltage ranges
* Arguments    : int data - voltage input data to compare with voltage range
* Return Value : int number_of_leds - return the number of leds to be turned on
******************************************************************************/
int range_choose(int data)
{
	/* Declare voltage array to be compared with voltage input*/
	int range_array[]={RANGE_ARRAY};
	
	/* Declare variable for number of leds to be turned on*/
	int number_of_leds=0;
	int i;
	
	/* Loop to compare 12 voltage range condition*/
	for (i=0;i<12;i++)
	{
		if(data>range_array[i])
		{
		/* Increased number of leds to be turned on for each satisfied range */
		number_of_leds++;
		}
	}
	
	/* Return the total number of leds to be turned on*/
	return number_of_leds;
}

/******************************************************************************
* Function Name: turn_off_leds
* Description  : turn off all leds
* Arguments    : none
* Return Value : none
******************************************************************************/
void turn_off_leds (void)
{
	PORT4	|=0x3C;
	PORT6	|=0xFC;
	PORT10	|=0x02;
	PORT15	|=0x04;
}

/******************************************************************************
* Function Name: led_on
* Description  : turn on the number of leds which have been choosen
* Arguments    : int n - number of leds to be turned on
* Return Value : none
******************************************************************************/
void led_on(int number_of_leds)
{
	int i;
	/* Turn off all leds before turning on specified leds*/
	turn_off_leds();
	
	/* Turn on specified leds */
	for(i=0;i<number_of_leds;i++)
	led_select(i);
}

/******************************************************************************
* Function Name: led_init
* Description  : initialize leds as output pin
* Arguments    : none
* Return Value : none
******************************************************************************/
void led_init (void)
{
	ADPC =1;
	PORT_MODE4 &= 0xC3;
	PORT_MODE6 &= 0x03;
	PORT_MODE10 &= 0xFD;
	PORT_MODE15 &= 0xFB;
}


