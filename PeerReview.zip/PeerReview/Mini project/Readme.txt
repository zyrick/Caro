The following work products are to be done by trainees:

1. Detailed Design
2. Source Code (folder: "Code")
3. Test PCL
4. Traceability
5. Review Minutes
6. Defect Tracking List