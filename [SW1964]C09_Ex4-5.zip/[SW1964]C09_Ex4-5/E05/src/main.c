/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized. This 
* software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING 
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT 
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE 
* AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR 
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE 
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software 
* and to discontinue the availability of this software.  By using this software, 
* you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2011, 2013 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : main.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements main function.
* Creation Date: 09-Sep-15
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_macro.h"
#include "r_spi_if.h"
#include "lcd.h"
#include "uart.h"
#include "sw.h"
#include "timer.h"
#include <string.h>

/******************************************************************************
Private global variables and functions
******************************************************************************/
unsigned int result = 0;
unsigned int remainder = 0;

/***********************************************************************************************************************
Funtion declaration
***********************************************************************************************************************/
void LCD_Reset(void);

/***********************************************************************************************************************
* Function Name: main
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void main(void)
{
    unsigned char LCD_Line = LCD_LINE3;
    char str2[2]  = {0x0D, 0x0A};
    char str1[13];
    char str3[13];
    /* Initialize UART1 communication */
    Uart_Init();
    
    /* Initialize external interrupt - SW1 */
    INTC_Create();
    
    /* Initialize interrupt - timer */
    R_IT_Create();
    
    /* Enable interrupt */
    EI();
    
    LCD_Reset();
    
    /* Initialize SPI channel used for LCD */
    R_SPI_Init(SPI_LCD_CHANNEL);
	
    /* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
    R_SPI_SslInit(
    SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
    (unsigned char *)&P14,   /* Select Port register */
    (unsigned char *)&PM14,  /* Select Port mode register */
    5,                       /* Select pin index in the port */
    0,                       /* Configure CS pin active state, 0 means active LOW level  */
    0                        /* Configure CS pin active mode, 0 means active per transfer */
    );
    
    /* Initialize LCD driver */
    InitialiseLCD();

    /* Clear LCD display */
    ClearLCD();
    
    /* Display information on the debug LCD.*/
    DisplayLCD(LCD_LINE1, (uint8_t *)"Simple math");
    DisplayLCD(LCD_LINE2, (uint8_t *)" operation  ");
    
    /* Start UART1 communication */
    Uart_Start();
    
    /* Start external interrupt - SW1 */
    INTC10_Start();
    
    /* Start interval timer */
    G_elapsedTime = 0;
    R_IT_Start();
    
    while (1U)
    {

	/* Check Swtich 1 edge */
	if('1' == gSwitchFlag)
	{
		if ((rx_buff[0] > 57) || (rx_buff[0] < 48)){
			DisplayLCD(LCD_LINE4, (uint8_t *)"Operand1 is");
			DisplayLCD(LCD_LINE5, (uint8_t *)"not valid");
		}
		else if ((rx_buff[2] > 57) || (rx_buff[2] < 48)){
			DisplayLCD(LCD_LINE4, (uint8_t *)"Operand2 is");
			DisplayLCD(LCD_LINE5, (uint8_t *)"not valid");
		}
		else if ((rx_buff[1] != 43) && (rx_buff[1] != 45) && (rx_buff[1] != 42) && (rx_buff[1] != 47))
		{
			DisplayLCD(LCD_LINE4, (uint8_t *)"Operator is");
			DisplayLCD(LCD_LINE5, (uint8_t *)"not valid");
		}
		else
		{
			if (rx_buff[1] == 43)
			{
				result = rx_buff[0] + rx_buff[2] - 96;
				if (result > 9){
					sprintf(str1, "%c + %c = %d%d  ", rx_buff[0], rx_buff[2], result/10, result%10);
				}
				else
				{
					sprintf(str1, "%c + %c = %d   ", rx_buff[0], rx_buff[2], result);
				}
			}
			else if (rx_buff[1] == 45)
			{
				if (rx_buff[0] < rx_buff[2])
				{
					result = rx_buff[2] - rx_buff[0];
					sprintf(str1, "%c - %c = -%d  ", rx_buff[0], rx_buff[2], result);
				}
				else
				{
					result = rx_buff[0] - rx_buff[2];
					sprintf(str1, "%c - %c = %d   ", rx_buff[0], rx_buff[2], result);
				}
			}
			else if (rx_buff[1] == 42)
			{
				result = (rx_buff[0] - 48) * (rx_buff[2] - 48);
				if (result > 9){
					sprintf(str1, "%c * %c = %d%d  ", rx_buff[0], rx_buff[2], result/10, result%10);
				}
				else
				{
					sprintf(str1, "%c * %c = %d   ", rx_buff[0], rx_buff[2], result);
				}
			}
			else if (rx_buff[1] == 47)
			{
				remainder = (rx_buff[0] - 48) % (rx_buff[2] - 48);
				result = (rx_buff[0] - 48) / (rx_buff[2] - 48);
				if (remainder != 0)
				{
					sprintf(str1, "%c / %c = %d   ", rx_buff[0], rx_buff[2], result);
					sprintf(str3, "remainder=%d", remainder);
					DisplayLCD(LCD_LINE5, (uint8_t *)(str3));
					Uart_Transmit(&(str3[0]), 13);
					Uart_Transmit(&(str2[0]), 2);
				}
				else
				{
					sprintf(str1, "%c / %c = %d   ", rx_buff[0], rx_buff[2], result);
				}
			}
			DisplayLCD(LCD_LINE4, (uint8_t *)(str1));
			Uart_Transmit(&(str1[0]), 13);
			Uart_Transmit(&(str2[0]), 2);
		}
	
		gSwitchFlag = 0;
	}
	else
	{
		/* Do nohing */
	}
	if (G_elapsedTime == 1) {
		G_elapsedTime = 0;
		/* Check UART1 receive status */
		if (status == UART_RECEIVE_DONE)
		{

			status = 0;
			
			/* Replace the last element by NULL */
			rx_buff[UART_RX_BUFFER_LEN - 1] = '\0';
				
			/* Display string in receive buffer */
			DisplayLCD(LCD_Line, (uint8_t *)(&rx_buff[0]));
				
			/* Cheking for display in next line */
			if(0 == (rx_count%12))
			{
				Uart_ClearBuff(&rx_buff[0], UART_RX_BUFFER_LEN - 1);
				LCD_Line = (unsigned char)(rx_count/12)*8 + LCD_LINE3;
			}
			else
			{
				/* Do nothing */
			}
		}
		else if (UART_CLEAR == cmd)
		{
			cmd = 0;
			rx_count = 0;
			ClearLCD();
			DisplayLCD(LCD_LINE1, (uint8_t *)"Simple math");
    			DisplayLCD(LCD_LINE2, (uint8_t *)" operation  ");
			Uart_ClearBuff(&rx_buff[0], UART_RX_BUFFER_LEN - 1);
			LCD_Line = LCD_LINE3;
		}
	}
	else
	{
		/* Do nothing */
	}
    }
    
    
}

void LCD_Reset(void)
{
    int i =0;
    /* Output a logic LOW level to external reset pin*/
    P13_bit.no0 = 0;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Generate a raising edge by ouput HIGH logic level to external reset pin */
    P13_bit.no0 = 1;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Output a logic LOW level to external reset pin, the reset is completed */
    P13_bit.no0 = 0;
}
/******************************************************************************
End of file
******************************************************************************/
