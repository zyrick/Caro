package carogame.groupseven.model;			// class contain public variables

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
public class Player {
	
	public static byte PLAYER_1 = 1;
	public static byte PLAYER_2 = 2;
	
	public static byte timeP1win = 0;
	public static byte timeP2win = 0;
	
	public static byte firstStep = 0;
	public static byte clickPlayer = 0;
	public static byte Winer = 0;
	public static Group group;
	public static Group grpPlayer1;
	public static Label congra1;
	public static Group grpPlayer2;
	public static Label congra2;
	public static Text Player1name;
	public static Text Player2name;
	public static Button btnBound;
	public static Button btnUnBound;
	public static Label	active;
	public static Label lblScore1;
	public static Label lblScore2;
	
	public static int state=1;
	public static int boundary_check=0;
	public static int win_time=0;
}
