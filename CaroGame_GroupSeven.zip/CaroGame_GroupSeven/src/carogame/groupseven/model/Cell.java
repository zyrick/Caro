package carogame.groupseven.model;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.eclipse.wb.swt.ResourceManager;
import org.eclipse.wb.swt.SWTResourceManager;

import carogame.groupseven.views.Board;


public class Cell extends Canvas{

	private CheckWiner iWiner = new CheckWiner();
	private static ImageDescriptor imgCross = AbstractUIPlugin.imageDescriptorFromPlugin("CaroGame_GroupSeven", "icons/4.png");
	private static ImageDescriptor imgNought = AbstractUIPlugin.imageDescriptorFromPlugin("CaroGame_GroupSeven", "icons/apple.png");
	private static ImageDescriptor imgCrossA = AbstractUIPlugin.imageDescriptorFromPlugin("CaroGame_GroupSeven", "icons/4.png");
	private static ImageDescriptor imgNoughtA = AbstractUIPlugin.imageDescriptorFromPlugin("CaroGame_GroupSeven", "icons/apple.png");
		
	static Image imageCross = imgCross.createImage();
	static Image imageNought = imgNought.createImage();
	static Image imageCrossA = imgCrossA.createImage();
	static Image imageNoughtA = imgNoughtA.createImage();
	static ImageData imageNoughtA_data = imgNoughtA.getImageData();
	static ImageData imageNought_data = imgNought.getImageData();
	static ImageData imageCross_data = imgCross.getImageData();
	static ImageData imageCrossA_data = imgCrossA.getImageData();
	 
	public byte C_Player = 0;
	public boolean Current_Player = false;
	public boolean W_CellFlag = false;
	public static int X_Before = 0;
	public static int Y_Before = 0;
	public static int OLDX_Before = 0;
	public static int OLDY_Before = 0;

	
	public Cell(Composite parent, int style) {
		super (parent, style);
		// TODO Auto-generated constructor stub	
		addListener(SWT.Paint, new Listener() { 	//All action take when drawing board
			
			@Override
			public void handleEvent(Event event) {
				// TODO Auto-generated method stub
				
				if(C_Player == Player.PLAYER_1)
				{
					if (Current_Player || W_CellFlag) {
						
						ImageData imageNoughtA_dt =  imageNoughtA_data.scaledTo((carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3),(carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3));
						Image tempNoughtA = new Image(imageNoughtA.getDevice() ,imageNoughtA_dt);
						event.gc.drawImage(tempNoughtA, 0, 0);
						Current_Player = false;
					}
					else
					{
						ImageData imageNought_dt =  imageNought_data.scaledTo((carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3),(carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3));
						Image tempNought = new Image(imageNought.getDevice() ,imageNought_dt);
						event.gc.drawImage(tempNought, 0, 0);
					}
				}
				else if(C_Player == Player.PLAYER_2)
				{
					if (Current_Player || W_CellFlag) {
						
						ImageData imageCrossA_dt =  imageCrossA_data.scaledTo((carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3),(carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3));
						Image tempCrossA = new Image(imageCrossA.getDevice() ,imageCrossA_dt);
						event.gc.drawImage(tempCrossA, 0, 0);
						Current_Player = false;
					}
					else
					{
						ImageData imageCross_dt =  imageCross_data.scaledTo((carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3),(carogame.groupseven.views.CaroView.mainBoard.getCell_W_H()-3));
						Image tempCross = new Image(imageCross.getDevice() ,imageCross_dt);
						event.gc.drawImage(tempCross, 0, 0);
					}
				}
				else
				{
					event.gc.setBackground(Display.getDefault().getSystemColor(SWT.COLOR_WHITE));
					event.gc.fillRectangle(0, 0, carogame.groupseven.views.CaroView.mainBoard.getCell_W_H() , carogame.groupseven.views.CaroView.mainBoard.getCell_W_H());
				}
				
			}
		});
		
		//All action take when mouse down
		addListener(SWT.MouseDown, new Listener() {
			
			private Board mainBoard;

			@Override
			public void handleEvent(Event event) {
				// TODO Auto-generated method stub
				
				if(!CheckWiner.won){
					if((C_Player != Player.PLAYER_1)&&(C_Player != Player.PLAYER_2)){
						//Check to lose player plays first.
						if(Player.Winer == Player.PLAYER_1){
							Player.clickPlayer = Player.PLAYER_2;
							C_Player = Player.PLAYER_2;
							Player.Winer = 0;
						}
						else if(Player.Winer == Player.PLAYER_2){
							Player.clickPlayer = Player.PLAYER_1;
							C_Player = Player.PLAYER_1;
							Player.Winer = 0;
						}
						else{
							if((Player.clickPlayer == Player.PLAYER_1)){
								Player.clickPlayer = Player.PLAYER_2;
								C_Player = Player.PLAYER_2;
							}
							else{
								Player.clickPlayer = Player.PLAYER_1;
								C_Player = Player.PLAYER_1;
							}
						}
						
						Current_Player = true;
						
						redraw();
						//Change avatar of each player after their turn
								if(Player.clickPlayer == Player.PLAYER_1)
							{
									Player.active.setBounds(310, 30, 30, 30);
									Player.active.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/41.png")));
									
								switch (Player.state)
								{
								case 1:
									Player.state=2;
									Player.grpPlayer1.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/15.jpeg")));
									break;
								case 2:
									Player.state=3;
									Player.grpPlayer1.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/13.jpeg")));
									break;
								case 3:
									Player.state=4;
									Player.grpPlayer1.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/12.jpg")));
									break;
								case 4:
									Player.state=5;
									Player.grpPlayer1.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/11.jpg")));
									break;
								case 5:
									Player.state=1;
									Player.grpPlayer1.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/10.jpeg")));
									break;
								}
							}
								else if(Player.clickPlayer == Player.PLAYER_2)
								{
									
									Player.active.setBounds(10, 30, 30, 30);
									Player.active.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/apple1.png")));
									switch (Player.state)
									{
									case 1:
										Player.state=2;
										Player.grpPlayer2.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/20.jpeg")));
										break;
									case 2:
										Player.state=3;
										Player.grpPlayer2.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/23.jpeg")));
										break;
									case 3:
										Player.state=4;
										Player.grpPlayer2.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/21.jpg")));
										break;
									case 4:
										Player.state=5;
										Player.grpPlayer2.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/22.jpg")));
										break;
									case 5:
										Player.state=1;
										Player.grpPlayer2.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/24.jpeg")));
										break;
									}
							}
						//Change parent theme every a match end
								
						
						/*Check win condition every time player click mouse*/
						if(iWiner.checkWinwer()){
							
							
							
							Player.win_time++;
							if(Player.Winer == Player.PLAYER_1)
							{
								//notification when player 1 win
								
								Player.congra1.setBounds(10, 150, 300, 100);
								Player.congra1.setText("Congratulation!"+System.lineSeparator() +Player.Player1name.getText()+"WIN!");
								Player.grpPlayer1.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/win.jpeg")));
								Player.congra2.setBounds(20, 150, 300, 100);
								Player.congra2.setText("LOSER!");
								Player.grpPlayer2.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/losing.jpeg")));
							}
							else
							{
								//notification when player 2 win
								
								Player.congra2.setBounds(10, 150, 300, 100);
								Player.congra2.setText("Congratulation!"+System.lineSeparator()  +Player.Player2name.getText()+"WIN!");
								Player.grpPlayer2.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/win.jpeg")));
								Player.congra1.setBounds(20, 150, 300, 100);
								Player.congra1.setText("LOSER!");
								Player.grpPlayer1.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/losing.jpeg")));
							}
							
							Player.lblScore1.setText(Player.timeP1win+"");
							Player.lblScore2.setText(Player.timeP2win+"");
						}
						
						if(Board.checkBoard()){
						//	NotifyMessage.notifyDraw();
						}
						
					}
				}
				
			}
		});
		
		
		addListener(SWT.MouseUp, new Listener(){		//method handle event 

			@Override
			public void handleEvent(Event event) {
				if(Player.firstStep != 0){
					Board.cell[OLDX_Before][OLDY_Before].redraw();
				}
				else{
					Player.firstStep = C_Player;
				}
				OLDX_Before = X_Before;
				OLDY_Before = Y_Before;
			}
			
		});
	}
	
	
}
