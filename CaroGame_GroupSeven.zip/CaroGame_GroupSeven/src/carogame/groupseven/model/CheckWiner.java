package carogame.groupseven.model;

import carogame.groupseven.views.Board;

public class CheckWiner {

	private int width = 0, height = 0;
	private Cell[][] cell;
	
	public static boolean won = false;
	public static byte numberOfCellToWin = 5;
	
	public CheckWiner(){
		this.width = Board.width;
		this.height = Board.height;
		this.cell = Board.cell;
	}
	
	public boolean checkWinwer(){ 		//main function to check win condition
		
		for(byte i = 0; i < width; i++){
			for(byte j = 0; j < height; j++){
				//check the current player
				if(cell[i][j].Current_Player == true){
					//Save cell index
					Cell.X_Before = i;
					Cell.X_Before = j;
					
					if (checkColumn(i, j)){
						return true;
					}
					else if(checkRow(i, j)){
						return true;
					}
					else if(checkCross(i, j)){
						return true;
					}
					else{
						return false;
					}
				}
			}
		}
		return false;
	}
	
	private boolean checkColumn(byte curColumn, byte curRow){		//column check win condition
		byte numberAppear = 0;
		byte illegalWin = 0;
		byte step = 0;
		
		for(byte i = curRow; i < height; i++){
			if(cell[curColumn][i].C_Player == cell[curColumn][curRow].C_Player){
				numberAppear++;
				Board.winCellInfo[step][0] = curColumn;
				Board.winCellInfo[step][1] = i;
				step++;
			}
			//check intercept
			else if(cell[curColumn][i].C_Player != 0){
				illegalWin++;
				break;
			}
			else{
				break;
			}
		}
		for(int i = curRow - 1; i >= 0; i--){
			if(cell[curColumn][i].C_Player == cell[curColumn][curRow].C_Player){
				numberAppear++;
				Board.winCellInfo[step][0] = curColumn;
				Board.winCellInfo[step][1] = (byte) i;
				step++;
			}
			//check intercept
			else if(cell[curColumn][i].C_Player != 0){
				illegalWin++;
				break;
			}
			else{
				break;
			}
		}
		if(Player.boundary_check==1)
		{
		if(illegalWin < 2){
			return checkNumberAppear(numberAppear, curColumn, curRow);
		}
		else{
			return false;
		}
		}
		else 
			return checkNumberAppear(numberAppear, curColumn, curRow);
		
	}
	
	private boolean checkRow(byte curColumn, byte curRow){		// row check win condition
		byte numberAppear = 0;
		byte illegalWin = 0;
		byte step = 0;
		
		for(byte i = curColumn; i < width; i++){
			if(cell[i][curRow].C_Player == cell[curColumn][curRow].C_Player){
				numberAppear++;
				Board.winCellInfo[step][0] = i;
				Board.winCellInfo[step][1] = curRow;
				step++;
			}
			//check intercept
			else if(cell[i][curRow].C_Player != 0){
				illegalWin++;
				break;
			}
			else{
				break;
			}
		}
		for(int i = curColumn - 1; i >= 0; i--){
			if(cell[i][curRow].C_Player == cell[curColumn][curRow].C_Player){
				numberAppear++;
				Board.winCellInfo[step][0] = (byte) i;
				Board.winCellInfo[step][1] = curRow;
				step++;
			}
			//check intercept
			else if(cell[i][curRow].C_Player != 0){
				illegalWin++;
				break;
			}
			else{
				break;
			}
		}
		
		if(Player.boundary_check==1)
		{
		if(illegalWin < 2){
			return checkNumberAppear(numberAppear, curColumn, curRow);
		}
		else{
			return false;
		}
		}
		else 
			return checkNumberAppear(numberAppear, curColumn, curRow);
	}
	
	private boolean checkCross(byte curColumn, byte curRow){		// cross check win condition
		byte numberAppear = 0;
		byte illegalWin = 0;
		byte step = 0;
		
		//we are going to verify from left (lower) to right (higher)
		for(int i = 0; i < (height > width ? width:height); i++){
			if(((curColumn - i) >= 0) && ((curRow + i) < height)){
				if(cell[curColumn - i][curRow + i].C_Player == cell[curColumn][curRow].C_Player){
					numberAppear++;
					Board.winCellInfo[step][0] = (byte) (curColumn - i);
					Board.winCellInfo[step][1] = (byte) (curRow + i);
					step++;
				}
				//check intercept
				else if(cell[curColumn - i][curRow + i].C_Player != 0){
					illegalWin++;
					break;
				}
				else{
					break;
				}
			}
			else{
				break;
			}
		}
		for(int i = 1; i < (height > width ? width:height); i++){
			if(((curColumn + i) < width) && ((curRow - i) >= 0)){
				if(cell[curColumn + i][curRow - i].C_Player == cell[curColumn][curRow].C_Player){
					numberAppear++;
					Board.winCellInfo[step][0] = (byte) (curColumn + i);
					Board.winCellInfo[step][1] = (byte) (curRow - i);
					step++;
				}
				//check intercept
				else if(cell[curColumn + i][curRow - i].C_Player != 0){
					illegalWin++;
					break;
				}
				else{
					break;
				}
			}
			else{
				break;
			}
		}
		
		if(numberAppear < CheckWiner.numberOfCellToWin){
			
			numberAppear = 0;
			illegalWin = 0;
			step = 0;
			
			//we are going to verify from left (higher) to right (lower)
			for(int i = 0; i < (height > width ? width:height); i++){
				if(((curColumn - i) >= 0) && ((curRow - i) >= 0)){
					if(cell[curColumn - i][curRow - i].C_Player == cell[curColumn][curRow].C_Player){
						numberAppear++;
						Board.winCellInfo[step][0] = (byte) (curColumn - i);
						Board.winCellInfo[step][1] = (byte) (curRow - i);
						step++;
					}
					//check intercept
					else if(cell[curColumn - i][curRow - i].C_Player != 0){
						illegalWin++;
						break;
					}
					else{
						break;
					}
				}
				else{
					break;
				}
			}
			for(int i = 1; i < (height > width ? width:height); i++){
				if(((curColumn + i) < width) && ((curRow + i) < height)){
					if(cell[curColumn + i][curRow + i].C_Player == cell[curColumn][curRow].C_Player){
						numberAppear++;
						Board.winCellInfo[step][0] = (byte) (curColumn + i);
						Board.winCellInfo[step][1] = (byte) (curRow + i);
						step++;
					}
					//check intercept
					else if(cell[curColumn + i][curRow + i].C_Player != 0){
						illegalWin++;
						break;
					}
					else{
						break;
					}
				}
				else{
					break;
				}
			}
		}
		
		if(Player.boundary_check==1)
		{
		if(illegalWin < 2){
			return checkNumberAppear(numberAppear, curColumn, curRow);
		}
		else{
			return false;
		}
		}
		else 
			return checkNumberAppear(numberAppear, curColumn, curRow);
	}
	
	private boolean checkNumberAppear(byte numberAppear, byte curColumn, byte curRow){			//function to check number of move appear of each player
		if(numberAppear == CheckWiner.numberOfCellToWin){								// win if numberAppear == numberOfCellToWin
			if(cell[curColumn][curRow].C_Player == Player.PLAYER_1){
				Player.Winer = Player.PLAYER_1;
				if(Player.timeP1win < 99)
					Player.timeP1win++;
				else
				{
					if(Player.timeP1win >= Player.timeP2win){
						Player.timeP1win = (byte) (Player.timeP1win - Player.timeP2win);
						Player.timeP2win = 0;
					}
					else {
						Player.timeP2win = (byte) (Player.timeP2win - Player.timeP1win);
						Player.timeP1win = 0;
					}
				}
			}
			else if(cell[curColumn][curRow].C_Player == Player.PLAYER_2){
				Player.Winer = Player.PLAYER_2;
				if(Player.timeP2win < 99)
					Player.timeP2win++;
				else
				{
					if(Player.timeP1win >= Player.timeP2win){
						Player.timeP1win = (byte) (Player.timeP1win - Player.timeP2win);
						Player.timeP2win = 0;
					}
					else {
						Player.timeP2win = (byte) (Player.timeP2win - Player.timeP1win);
						Player.timeP1win = 0;
					}
				}
			}
			CheckWiner.won = true;
			return true;
		}
		else{
			return false;
		}
	}
	
}
