package carogame.groupseven.views;
// Class to draw board
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.ResourceManager;
import org.eclipse.wb.swt.SWTResourceManager;

import carogame.groupseven.model.Cell;
import carogame.groupseven.model.CheckWiner;
import carogame.groupseven.model.Player;
public class Board {

	private static int MAX_WIDTH_HEIGHT = 50;
	private static int MIN_WIDTH_HEIGHT = 10;
	private static int X_START = 20;
	private static int Y_START = 0;
	private static int SIZE = 600;
	public static byte winCellInfo[][] = new byte[5][2];
	private int Cell_W_H;
	public static boolean drawFlag = false;
	
	public int getCell_W_H() {
		return Cell_W_H;
	}

	public void setCell_W_H(int cell_W_H) {
		Cell_W_H = cell_W_H;
	}
	
	private boolean cFlag = false;
	public static int width = 0, height = 0;
	
	public static byte Win_info[][] = new byte [5][2];
	
 	public static Cell[][] cell = null;
 	
 	public void Calcu_CELL(int height, int wight)
 	{
 		Cell_W_H = SIZE/height;
 	}
 	
 	public boolean initBoard (int width, int height)	//method initialize to draw board
 	{
 		if((width > MAX_WIDTH_HEIGHT)||(width < MIN_WIDTH_HEIGHT)||(height > MAX_WIDTH_HEIGHT)||(height < MIN_WIDTH_HEIGHT)||(width!=height)){
			return false;
		}
 		else
 		{ 
 			if(cFlag)
 			{
 				deleteBoard();
 			}
 			cFlag = true;
 			Board.width = width;
 			Board.height = height;
 			return true;
 		}
 		
 	}
 	
 	public void drawBoard()	//method to draw board
 	{
 		cell = new Cell[(int) width][(int) height];
 		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				
				cell[i][j] = new Cell(carogame.groupseven.views.CaroView.Boardparent, SWT.BORDER);
				cell[i][j].setBounds((int)(X_START + i * Cell_W_H), (int)(Y_START + j* Cell_W_H), (int)Cell_W_H, (int)Cell_W_H);
				cell[i][j].setBackgroundImage(ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/cross.png"));
				
			}
		}
 	}
 	
 	public static boolean checkBoard(){		//check if draw condition appear
		
		for(int i = 0; i < Board.width; i++){
			for(int j = 0; j < Board.height; j++){
				if(Board.cell[i][j].C_Player == 0){
					drawFlag = false;
					return false;
				}
			}
		}
		drawFlag = true;
		return true;
	}
 	
 	
 	public void deleteBoard()		//method to delete board
 	{
 		Player.clickPlayer = 0;
		CheckWiner.won = false;
		drawFlag = false;
	//	Message.notifyWiner();
		for(int i = 0; i < width; i++){
			for(int j = 0; j < height; j++){
				cell[i][j].C_Player = 0;
				cell[i][j].Current_Player = false;
				cell[i][j].W_CellFlag = false;
				cell[i][j].dispose();
			}
		}
 	}
 	
 	public static void reCreateBoard(){			//method create board
		for(int i = 0; i < Board.width; i++){
			for(int j = 0; j < Board.height; j++){
				Board.cell[i][j].redraw();
			}
		}
	}
 	
 	
 	
}
