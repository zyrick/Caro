package carogame.groupseven.views;


import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.*;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.eclipse.wb.swt.SWTResourceManager;

import carogame.groupseven.model.CheckWiner;
import carogame.groupseven.model.Player;

import org.eclipse.jface.viewers.*;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.jface.action.*;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.*;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ViewForm;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Label;
import org.eclipse.wb.swt.ResourceManager;




/**
 * This sample class demonstrates how to plug-in a new
 * workbench view. The view shows data obtained from the
 * model. The sample creates a dummy model on the fly,
 * but a real implementation would connect to the model
 * available either in this or another plug-in (e.g. the workspace).
 * The view is connected to the model using a content provider.
 * <p>
 * The view uses a label provider to define how model
 * objects should be presented in the view. Each
 * view can present the same model objects using
 * different labels and icons, if needed. Alternatively,
 * a single label provider can be shared between views
 * in order to ensure that objects of the same type are
 * presented in the same way everywhere.
 * <p>
 */

public class CaroView extends ViewPart {

	/**
	 * The ID of the view as specified by the extension.
	 */
	public static final String ID = "carogame.groupseven.views.CaroView";
	private Text txtSize;
	public static Composite Boardparent;
	public static Board mainBoard;
	
	
	private static ImageDescriptor imaPlayerO = AbstractUIPlugin.imageDescriptorFromPlugin("CaroGame_GroupSeven", "icons/playerO.png");
	
	Image imagePlayerO = imaPlayerO.createImage();

	/**
	 * The constructor.
	 */
	public CaroView() {
		mainBoard = new Board();
	}

	/**
	 * This is a callback that will allow us
	 * to create the viewer and initialize it.
	 */
	// method to display user interface
	public void createPartControl(Composite parent) {
		Boardparent = parent;
		parent.setLayout(null);
//Group_player1 : contain player 1 name and player 1 avatar 		
		Player.grpPlayer1 = new Group(parent, SWT.NONE);
		Player.grpPlayer1.setBounds(660, 0, 300, 250);
		Player.grpPlayer1.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/15.jpeg")));
		
		Player.congra1 = new Label(Player.grpPlayer1, SWT.NONE);
		Player.congra1.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		Player.congra1.setAlignment(SWT.CENTER);
		Player.congra1.setFont(SWTResourceManager.getFont("Times New Roman", 25, SWT.BOLD));
		Player.congra1.setBounds(10, 150, 300, 100);
		
		Group group1_layer1= new Group(parent, SWT.CENTER);
		group1_layer1.setBounds(660, 250, 300, 50);
		group1_layer1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		Label lblPlayer1 = new Label(group1_layer1, SWT.NONE);
		lblPlayer1.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		lblPlayer1.setAlignment(SWT.CENTER);
		lblPlayer1.setFont(SWTResourceManager.getFont("Times New Roman", 25, SWT.BOLD));
		lblPlayer1.setBounds(5, 10, 100, 48);
		lblPlayer1.setText("Player :");
		
		Player.Player1name = new Text(group1_layer1, SWT.BORDER | SWT.CENTER);
		Player.Player1name.setBounds(110, 15, 180, 30);
		Player.Player1name.setFont(SWTResourceManager.getFont("Times New Roman", 18, SWT.NORMAL));
		Player.Player1name.setBackground(SWTResourceManager.getColor(SWT.COLOR_RED));
		
		
		
//Group_player1 : contain player 2 name and player 2 avatar 
		Player.grpPlayer2 = new Group(parent, SWT.NONE);
		Player.grpPlayer2.setBounds(960, 0, 300, 250);
		Player.grpPlayer2.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/20.jpeg")));
		
		Player.congra2 = new Label(Player.grpPlayer2, SWT.NONE);
		Player.congra2.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		Player.congra2.setAlignment(SWT.CENTER);
		Player.congra2.setFont(SWTResourceManager.getFont("Times New Roman", 25, SWT.BOLD));
		Player.congra2.setBounds(50, 150, 300, 100);
		
		Group group2_layer1= new Group(parent, SWT.CENTER);
		group2_layer1.setBounds(960, 250, 300, 50);
		group2_layer1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		Label lblPlayer2 = new Label(group2_layer1, SWT.CENTER);
		lblPlayer2.setForeground(SWTResourceManager.getColor(SWT.COLOR_BLACK));
		lblPlayer2.setFont(SWTResourceManager.getFont("Times New Roman", 25, SWT.BOLD));
		lblPlayer2.setBounds(5, 10, 100, 38);
		lblPlayer2.setText("Player :");
		
		Player.Player2name = new Text(group2_layer1, SWT.BORDER | SWT.CENTER);
		Player.Player2name.setBounds(110, 15, 180, 30);
		Player.Player2name.setBackground(SWTResourceManager.getColor(SWT.COLOR_GREEN));
		Player.Player2name.setFont(SWTResourceManager.getFont("Times New Roman", 18, SWT.NORMAL));
		
		
		
/*parent group layout for menu interface */			
		Player.group = new Group(parent, SWT.NONE);	
		Player.group.setBounds(660,300, 600, 250);
		Player.group.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/theme.jpeg")));
/*player1 score layout */			
		Group grpScore_player1 = new Group(Player.group, SWT.NONE);
		grpScore_player1.setBounds(50, 10, 200, 72);
		
		Player.active= new Label(Player.group, SWT.NONE);
		Player.active.setBounds(10, 30, 30, 30);
		Player.active.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/apple1.png")));
		
		Label lblPlayer1_score = new Label(grpScore_player1, SWT.NONE);
		lblPlayer1_score.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblPlayer1_score.setAlignment(SWT.CENTER);
		lblPlayer1_score.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.BOLD));
		lblPlayer1_score.setBounds(30, 10, 150, 26);
		lblPlayer1_score.setText("SCORE");
		
		Player.lblScore1 = new Label(grpScore_player1, SWT.NONE);
		Player.lblScore1.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		Player.lblScore1.setAlignment(SWT.CENTER);
		Player.lblScore1.setFont(SWTResourceManager.getFont("Times New Roman", 20, SWT.BOLD));
		Player.lblScore1.setBounds(55, 30, 100, 39);
		Player.lblScore1.setText(Player.timeP1win+"");
/*player2 score layout */			
		Group grpScore_player2 = new Group(Player.group, SWT.NONE);
		grpScore_player2.setBounds(350, 10, 200, 72);
		
		Label lblPlayer2_score = new Label(grpScore_player2, SWT.NONE);
		lblPlayer2_score.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblPlayer2_score.setAlignment(SWT.CENTER);
		lblPlayer2_score.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.BOLD));
		lblPlayer2_score.setBounds(30, 10, 150, 26);
		lblPlayer2_score.setText("SCORE");
		
		Player.lblScore2 = new Label(grpScore_player2, SWT.NONE);
		Player.lblScore2.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		Player.lblScore2.setAlignment(SWT.CENTER);
		Player.lblScore2.setFont(SWTResourceManager.getFont("Times New Roman", 20, SWT.BOLD));
		Player.lblScore2.setBounds(55, 30, 100, 39);
		Player.lblScore2.setText(Player.timeP2win+"");
/*button layout and event handler*/		
		Button btnNewGame = new Button(Player.group, SWT.NONE);
		btnNewGame.setBounds(20, 120, 150, 40);
		btnNewGame.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.BOLD));
		btnNewGame.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(mainBoard.initBoard(getWidth(), getHeight()))
				{
					mainBoard.Calcu_CELL(getWidth(), getHeight());
					mainBoard.drawBoard();
					
					Player.congra1.setText("");
					Player.grpPlayer1.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/15.jpeg")));
					Player.congra2.setText("");
					Player.grpPlayer2.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/20.jpeg")));
					switch ((Player.win_time%2))
					{
					case 0:
						
						parent.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/fall1.jpeg")));
						break;
					case 1:
						
						parent.setBackgroundImage((ResourceManager.getPluginImage("CaroGame_GroupSeven", "icons/winter1.jpeg")));
						break;
					}
				}
			}
		});
		btnNewGame.setText("NEW GAME");
		
		Button btnReSet = new Button(Player.group, SWT.NONE);
		btnReSet.setBounds(20, 180, 150, 40);
		btnReSet.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_DARK_SHADOW));
		btnReSet.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.BOLD));
		btnReSet.setText("NEW ROUND");
		btnReSet.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(mainBoard.initBoard(getWidth(), getHeight()))
				{
					Player.timeP1win=0;
					Player.timeP2win=0;
					Player.lblScore1.setText(Player.timeP1win+"");
					Player.lblScore2.setText(Player.timeP2win+"");
				}
			}
		});
		
		Player.btnBound = new Button(Player.group, SWT.RADIO);
		Player.btnBound.setBounds(360, 110, 150, 40);
		Player.btnBound.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_DARK_SHADOW));
		Player.btnBound.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.BOLD));
		Player.btnBound.setText("Boundary Check");
		
		Player.btnUnBound = new Button(Player.group, SWT.RADIO);
		Player.btnUnBound.setBounds(360, 180, 150, 40);
		Player.btnUnBound.setForeground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_DARK_SHADOW));
		Player.btnUnBound.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.BOLD));
		Player.btnUnBound.setText("UnBoundary Check");
		
		Player.btnBound.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
					Player.btnBound.setSelection(true);
					Player.btnUnBound.setSelection(false);
					Player.boundary_check=1;
				
			}
		});
		Player.btnUnBound.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
					Player.btnBound.setSelection(false);
					Player.btnUnBound.setSelection(true);
					Player.boundary_check=0;
				
			}
		});
/*size table layout */		
		Label lblSize = new Label(Player.group, SWT.NONE);
		lblSize.setBounds(200, 120,170, 21);
		lblSize.setAlignment(SWT.LEFT);
		lblSize.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.BOLD));
		lblSize.setText("Size from 10 to 50");
		
		txtSize = new Text(Player.group, SWT.BORDER | SWT.CENTER);
		txtSize.setBounds(200, 150, 130, 30);
		txtSize.setFont(SWTResourceManager.getFont("Times New Roman", 13, SWT.NORMAL));
		
	}
	//method to get board width
	private int getWidth()
	{
		int width = Integer.parseInt(txtSize.getText());
		return width;
	}
	
	//method to get board height
	private int getHeight()
	{
		int height = Integer.parseInt(txtSize.getText());
		return height;
	}
	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
		
	}
}
